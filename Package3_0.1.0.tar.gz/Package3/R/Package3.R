#' This is a description of Package 3
#' 
#' I will probably include in this package mutation data for ARID1A that I'll get from TumorPortal
#' 
#' I don't know if I'll use it for anything else
#' 
#' Maybe I'll include some function in this package as well
#' 
#' @name Package3
#' @docType package
#' 
NULL